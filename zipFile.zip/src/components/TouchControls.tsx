import { useCallback } from 'react';
import type { TouchState } from '../game/GameCanvas';

interface Props {
  touchRef: React.MutableRefObject<TouchState>;
  scale: number;
  visible: boolean;
}

export default function TouchControls({ touchRef, scale, visible }: Props) {
  if (!visible) return null;

  const bind = useCallback(
    (key: keyof TouchState) => ({
      onPointerDown: (e: React.PointerEvent) => {
        e.preventDefault();
        (e.target as Element).setPointerCapture?.(e.pointerId);
        touchRef.current[key] = true;
      },
      onPointerUp: (e: React.PointerEvent) => {
        e.preventDefault();
        touchRef.current[key] = false;
      },
      onPointerLeave: () => {
        touchRef.current[key] = false;
      },
      onPointerCancel: () => {
        touchRef.current[key] = false;
      },
    }),
    [touchRef]
  );

  const btnBase =
    'flex items-center justify-center rounded-full border-2 select-none touch-none active:scale-95 transition-transform font-bold backdrop-blur-sm';

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-30 flex items-end justify-between px-6 pb-6 sm:px-10 sm:pb-10">
      <div className="pointer-events-auto flex gap-4" style={{ transform: `scale(${scale})`, transformOrigin: 'bottom left' }}>
        <button
          {...bind('left')}
          className={`${btnBase} h-16 w-16 border-cyan-400/60 bg-cyan-400/10 text-cyan-300 text-2xl shadow-[0_0_20px_rgba(34,211,238,0.35)]`}
        >
          ◀
        </button>
        <button
          {...bind('right')}
          className={`${btnBase} h-16 w-16 border-cyan-400/60 bg-cyan-400/10 text-cyan-300 text-2xl shadow-[0_0_20px_rgba(34,211,238,0.35)]`}
        >
          ▶
        </button>
      </div>
      <div className="pointer-events-auto" style={{ transform: `scale(${scale})`, transformOrigin: 'bottom right' }}>
        <button
          {...bind('jump')}
          className={`${btnBase} h-20 w-20 border-fuchsia-400/60 bg-fuchsia-400/10 text-fuchsia-300 text-sm shadow-[0_0_20px_rgba(232,121,249,0.35)]`}
        >
          JUMP
        </button>
      </div>
    </div>
  );
}
