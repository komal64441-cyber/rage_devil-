import { useEffect } from 'react';

// Google AdSense IDs (for web version)
const AD_CLIENT_ID = 'ca-pub-1234567891234567'; // Placeholder - replace with your real ID
const AD_SLOT_ID = '9876543210'; // Placeholder - replace with your real slot

interface AdProps {
  slotId?: string;
  className?: string;
  style?: React.CSSProperties;
}

// Check if running in Capacitor (native Android/iOS)
const isCapacitor = () => typeof window !== 'undefined' && !!(window as any).Capacitor;

// Load AdSense script once
let adsenseLoaded = false;
const loadAdSenseScript = () => {
  if (adsenseLoaded || typeof window === 'undefined') return;
  
  const script = document.createElement('script');
  script.async = true;
  script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${AD_CLIENT_ID}`;
  script.crossOrigin = 'anonymous';
  script.dataset.adChannel = '';
  
  const meta = document.createElement('meta');
  meta.name = 'google-adsense-account';
  meta.content = AD_CLIENT_ID;
  
  document.head.appendChild(meta);
  document.head.appendChild(script);
  adsenseLoaded = true;
};

export function AdBanner({ slotId, className = '', style }: AdProps) {
  const adSlot = slotId || AD_SLOT_ID;
  
  useEffect(() => {
    // Only load ads on web, not in Capacitor/Android
    if (typeof window !== 'undefined' && !isCapacitor()) {
      loadAdSenseScript();
    }
  }, []);

  // Don't render ads in native Android (AdMob handles those)
  if (typeof window !== 'undefined' && isCapacitor()) {
    return null;
  }

  return (
    <div className={`w-full overflow-hidden ${className}`} style={style}>
      {/* Placeholder AdSense ad unit for testing responsive layout */}
      <ins
        className="adsbygoogle"
        style={{ display: 'block', width: '100%', maxWidth: '728px', margin: '0 auto' }}
        data-ad-client={AD_CLIENT_ID}
        data-ad-slot={adSlot}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </div>
  );
}

export function AdBannerInit() {
  useEffect(() => {
    if (typeof window !== 'undefined' && !isCapacitor()) {
      loadAdSenseScript();
    }
  }, []);
  
  return null;
}

// Initialize the ad after render
export function useAdInit() {
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        if (typeof window !== 'undefined' && (window as any).adsbygoogle && !isCapacitor()) {
          (window as any).adsbygoogle.push({});
        }
      } catch (e) {
        console.log('[AdSense] Ad init error:', e);
      }
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);
}