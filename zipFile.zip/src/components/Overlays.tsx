import type { Level } from '../game/types';

export function LevelCompleteOverlay({
  level,
  deaths,
  onNext,
  onMenu,
  onCopyLink,
  copyMsg,
  isLast,
}: {
  level: Level;
  deaths: number;
  onNext: () => void;
  onMenu: () => void;
  onCopyLink: () => void;
  copyMsg: string | null;
  isLast: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 px-4">
      <div className="w-full max-w-md rounded-2xl border border-emerald-400/30 bg-slate-900 p-8 text-center shadow-2xl">
        <p className="text-xs uppercase tracking-widest text-slate-500">Level {level.id} Complete</p>
        <h2 className="mt-2 text-3xl font-black text-emerald-400">{level.name}</h2>
        <p className="mt-1 text-sm text-slate-400">You survived... barely.</p>
        <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-sm">
          <span className="text-slate-400">💀 Deaths so far</span>
          <span className="font-mono font-bold text-red-400">{deaths}</span>
        </div>
        <div className="mt-6 flex flex-col gap-3">
          {!isLast && (
            <button
              onClick={onNext}
              className="rounded-xl bg-cyan-400 px-6 py-3 font-bold text-slate-950 hover:bg-cyan-300 transition-colors"
            >
              Next Level →
            </button>
          )}
          <button
            onClick={onMenu}
            className="rounded-xl border border-white/20 bg-white/5 px-6 py-3 font-semibold hover:bg-white/10 transition-colors"
          >
            Level Select
          </button>
          <button
            onClick={onCopyLink}
            className="rounded-xl border border-fuchsia-400/40 bg-fuchsia-400/10 px-6 py-3 font-semibold text-fuchsia-300 hover:bg-fuchsia-400/20 transition-colors"
          >
            🔗 Copy Link to Troll Your Friends
          </button>
        </div>
        {copyMsg && <p className="mt-2 text-xs text-emerald-400">{copyMsg}</p>}
      </div>
    </div>
  );
}

export function VictoryOverlay({
  deaths,
  onMenu,
  onCopyLink,
  copyMsg,
}: {
  deaths: number;
  onMenu: () => void;
  onCopyLink: () => void;
  copyMsg: string | null;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 px-4">
      <div className="w-full max-w-lg rounded-2xl border border-yellow-400/30 bg-slate-900 p-8 text-center shadow-2xl">
        <h2 className="text-4xl font-black bg-gradient-to-r from-cyan-400 via-fuchsia-400 to-yellow-300 bg-clip-text text-transparent">
          GRAND VICTORY
        </h2>
        <p className="mt-3 text-slate-300">
          You beat all 35 levels of <span className="font-bold text-white">Rage Devil</span>. Every falling
          platform, every runaway flag, every scrambled key — conquered.
        </p>
        <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-sm">
          <span className="text-slate-400">💀 Total Deaths</span>
          <span className="font-mono font-bold text-red-400">{deaths}</span>
        </div>
        <div className="mt-6 flex flex-col gap-3">
          <button
            onClick={onCopyLink}
            className="rounded-xl bg-fuchsia-400 px-6 py-3 font-bold text-slate-950 hover:bg-fuchsia-300 transition-colors"
          >
            🔗 Copy Link to Troll Your Friends
          </button>
          <button
            onClick={onMenu}
            className="rounded-xl border border-white/20 bg-white/5 px-6 py-3 font-semibold hover:bg-white/10 transition-colors"
          >
            Back to Menu
          </button>
        </div>
        {copyMsg && <p className="mt-2 text-xs text-emerald-400">{copyMsg}</p>}
      </div>
    </div>
  );
}
