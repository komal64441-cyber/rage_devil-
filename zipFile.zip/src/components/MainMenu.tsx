import { useState } from 'react';
import { LEVELS, WORLDS } from '../game/levels';

interface Props {
  deaths: number;
  completed: Set<number>;
  muted: boolean;
  touchScale: number;
  onMuteToggle: () => void;
  onTouchScaleChange: (v: number) => void;
  onStart: (levelId: number) => void;
  onCopyLink: () => void;
  copyMsg: string | null;
}

// Separate Level Selector Modal Component
function LevelSelectorModal({
  show,
  onClose,
  completed,
  highestUnlocked,
  onStart,
}: {
  show: boolean;
  onClose: () => void;
  completed: Set<number>;
  highestUnlocked: number;
  onStart: (levelId: number) => void;
}) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4">
      <div className="relative w-full max-w-2xl rounded-3xl border-2 border-cyan-400/30 bg-slate-900/95 p-6 shadow-2xl backdrop-blur-lg">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-cyan-400">Level Select</h2>
          <button
            onClick={onClose}
            className="rounded-full border border-white/20 bg-white/10 px-3 py-1 text-sm font-bold hover:bg-white/20"
          >
            ✕ Close
          </button>
        </div>
        
        <div className="max-h-[60vh] overflow-y-auto pr-2">
          {WORLDS.map((w) => (
            <div key={w.world} className="mb-6">
              <h3 className="mb-3 text-sm font-bold uppercase tracking-widest text-slate-400">{w.title}</h3>
              <div className="grid grid-cols-5 gap-3">
                {LEVELS.filter((l) => l.world === w.world).map((lvl) => {
                  const unlocked = lvl.id <= highestUnlocked;
                  const done = completed.has(lvl.id);
                  return (
                    <button
                      key={lvl.id}
                      disabled={!unlocked}
                      onClick={() => onStart(lvl.id)}
                      title={lvl.name}
                      className={`relative aspect-square rounded-xl border-2 text-sm font-bold transition-all duration-200 flex flex-col items-center justify-center gap-1 ${
                        unlocked
                          ? done
                            ? 'border-emerald-400/50 bg-emerald-400/20 text-emerald-300 shadow-lg shadow-emerald-400/20 hover:bg-emerald-400/30 hover:scale-105'
                            : 'border-cyan-400/50 bg-cyan-400/20 text-cyan-300 shadow-lg shadow-cyan-400/20 hover:bg-cyan-400/30 hover:scale-105'
                          : 'border-white/10 bg-white/5 text-slate-600 cursor-not-allowed'
                      }`}
                    >
                      <span className="text-lg">{unlocked ? lvl.id : '🔒'}</span>
                      {done && <span className="text-[10px] font-normal">✓ DONE</span>}
                      {!unlocked && <span className="text-[8px] font-normal mt-1">LOCKED</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 text-center text-xs text-slate-500">
          Tap any level to play. Completed levels show ✓
        </div>
      </div>
    </div>
  );
}

export default function MainMenu({
  deaths,
  completed,
  muted,
  touchScale,
  onMuteToggle,
  onTouchScaleChange,
  onStart,
  onCopyLink,
  copyMsg,
}: Props) {
  const [showSettings, setShowSettings] = useState(false);
  const [showLevels, setShowLevels] = useState(false);

  // UNLOCK ALL LEVELS
  const highestUnlocked = LEVELS.length;
  const nextLevel = Math.min(highestUnlocked, LEVELS.length);

  return (
    <div className="relative flex min-h-screen w-full flex-col items-center justify-center overflow-hidden bg-[#05060a] px-4 py-10 text-white">
      <div className="pointer-events-none absolute inset-0 opacity-40" style={{
        backgroundImage: 'radial-gradient(circle at 20% 20%, rgba(34,211,238,0.15), transparent 40%), radial-gradient(circle at 80% 70%, rgba(232,121,249,0.15), transparent 40%)'
      }} />

      <div className="relative z-10 flex w-full max-w-2xl flex-col items-center text-center">
        <h1 className="text-5xl sm:text-6xl font-black tracking-tight">
          <span className="text-cyan-400 drop-shadow-[0_0_20px_rgba(34,211,238,0.6)]">RAGE</span>{' '}
          <span className="text-fuchsia-400 drop-shadow-[0_0_20px_rgba(232,121,249,0.6)]">DEVIL</span>
        </h1>
        <p className="mt-3 text-sm sm:text-base text-slate-400 max-w-md">
          A minimalist neon platformer that lies to you. 35 levels. 4 worlds. Zero mercy.
        </p>

        <div className="mt-6 flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-5 py-2 text-sm">
          <span className="text-slate-400">💀 Total Deaths</span>
          <span className="font-mono text-lg font-bold text-red-400">{deaths}</span>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => onStart(nextLevel)}
            className="rounded-xl bg-cyan-400 px-8 py-3 font-bold text-slate-950 shadow-[0_0_25px_rgba(34,211,238,0.5)] hover:bg-cyan-300 transition-colors"
          >
            {highestUnlocked > 1 ? `Continue — Level ${nextLevel}` : 'Play Level 1'}
          </button>
          <button
            onClick={() => setShowLevels((v) => !v)}
            className="rounded-xl border border-white/20 bg-white/5 px-6 py-3 font-semibold hover:bg-white/10 transition-colors"
          >
            Level Select
          </button>
          <button
            onClick={() => setShowSettings((v) => !v)}
            className="rounded-xl border border-white/20 bg-white/5 px-6 py-3 font-semibold hover:bg-white/10 transition-colors"
          >
            ⚙ Settings
          </button>
          <button
            onClick={onCopyLink}
            className="rounded-xl border border-fuchsia-400/40 bg-fuchsia-400/10 px-6 py-3 font-semibold text-fuchsia-300 hover:bg-fuchsia-400/20 transition-colors"
          >
            🔗 Copy Link to Troll Your Friends
          </button>
        </div>
        {copyMsg && <p className="mt-2 text-xs text-emerald-400">{copyMsg}</p>}

        {showSettings && (
          <div className="mt-6 w-full rounded-2xl border border-white/10 bg-white/5 p-5 text-left">
            <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-300">Settings</h3>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-slate-300">Sound & Music</span>
              <button
                onClick={onMuteToggle}
                className={`rounded-full px-4 py-1 text-xs font-bold ${muted ? 'bg-slate-700 text-slate-300' : 'bg-emerald-500 text-slate-950'}`}
              >
                {muted ? 'Muted' : 'On'}
              </button>
            </div>
            <div className="py-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-300">Touch Control Size</span>
                <span className="text-xs text-slate-400">{Math.round(touchScale * 100)}%</span>
              </div>
              <input
                type="range"
                min={0.7}
                max={1.8}
                step={0.05}
                value={touchScale}
                onChange={(e) => onTouchScaleChange(parseFloat(e.target.value))}
                className="mt-2 w-full accent-cyan-400"
              />
            </div>
            <p className="mt-2 text-xs text-slate-500">Touch controls auto-appear on mobile/tablet devices, bottom-left (move) and bottom-right (jump).</p>
          </div>
        )}

        <LevelSelectorModal
        show={showLevels}
        onClose={() => setShowLevels(false)}
        completed={completed}
        highestUnlocked={highestUnlocked}
        onStart={onStart}
      />
      </div>

      <p className="relative z-10 mt-10 text-xs text-slate-600">Arrow Keys / WASD to move &amp; jump. Trust nothing.</p>
    </div>
  );
}
