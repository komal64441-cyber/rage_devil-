import { useEffect, useRef, useState, useCallback } from 'react';
import GameCanvas, { type TouchState, type ControlIndicator } from './game/GameCanvas';
import { LEVELS } from './game/levels';
import TouchControls from './components/TouchControls';
import MainMenu from './components/MainMenu';
import { LevelCompleteOverlay, VictoryOverlay } from './components/Overlays';
import { audio } from './game/audio';
import { ads } from './services/AdsManager';
import { AdBanner, AdBannerInit } from './components/AdSense';

type Screen = 'menu' | 'playing' | 'levelComplete' | 'victory';

const LS_DEATHS = 'rd_deaths';
const LS_COMPLETED = 'rd_completed';
const LS_MUTED = 'rd_muted';
const LS_TOUCH_SCALE = 'rd_touch_scale';

function loadCompleted(): Set<number> {
  try {
    const raw = localStorage.getItem(LS_COMPLETED);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [currentLevelId, setCurrentLevelId] = useState(1);
  const [deaths, setDeaths] = useState<number>(() => {
    const v = localStorage.getItem(LS_DEATHS);
    return v ? parseInt(v, 10) : 0;
  });
  const [completed, setCompleted] = useState<Set<number>>(() => loadCompleted());
  const [muted, setMuted] = useState<boolean>(() => localStorage.getItem(LS_MUTED) === '1');
  const [touchScale, setTouchScale] = useState<number>(() => {
    const v = localStorage.getItem(LS_TOUCH_SCALE);
    return v ? parseFloat(v) : 1;
  });
  const [copyMsg, setCopyMsg] = useState<string | null>(null);
  const [controlIndicator, setControlIndicator] = useState<ControlIndicator | null>(null);
  const [isTouchDevice] = useState(() => typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0));

  const touchRef = useRef<TouchState>({ left: false, right: false, jump: false });
  const levelsCompletedCount = useRef(0);

  // Initialize ads on first load
  useEffect(() => {
    ads.initialize().then(() => {
      // Prepare first interstitial once initialized
      ads.prepareInterstitial().catch(() => {});
    });
  }, []);

  // Show banner when playing
  useEffect(() => {
    if (screen === 'playing') {
      ads.showBanner().catch(() => {});
    } else {
      ads.hideBanner().catch(() => {});
    }
  }, [screen]);

  useEffect(() => {
    localStorage.setItem(LS_DEATHS, String(deaths));
  }, [deaths]);
  useEffect(() => {
    localStorage.setItem(LS_COMPLETED, JSON.stringify(Array.from(completed)));
  }, [completed]);
  useEffect(() => {
    localStorage.setItem(LS_MUTED, muted ? '1' : '0');
  }, [muted]);
  useEffect(() => {
    localStorage.setItem(LS_TOUCH_SCALE, String(touchScale));
  }, [touchScale]);

  const level = LEVELS.find((l) => l.id === currentLevelId) || LEVELS[0];
  const isLastLevel = currentLevelId === LEVELS.length;

  const copyLink = useCallback(() => {
    const url = `${window.location.origin}${window.location.pathname}`;
    navigator.clipboard
      .writeText(url)
      .then(() => setCopyMsg('Link copied! Go ruin someone\'s day.'))
      .catch(() => setCopyMsg('Could not copy — copy it manually.'));
    setTimeout(() => setCopyMsg(null), 2500);
    audio.click();
  }, []);

  const handleStart = useCallback((levelId: number) => {
    audio.resume();
    setCurrentLevelId(levelId);
    setControlIndicator(null);
    setScreen('playing');
  }, []);

  const handleDeath = useCallback(() => {
    setDeaths((d) => d + 1);
  }, []);

  const handleComplete = useCallback(() => {
    setCompleted((prev) => {
      const next = new Set(prev);
      next.add(currentLevelId);
      return next;
    });
    setScreen(currentLevelId === LEVELS.length ? 'victory' : 'levelComplete');
    
    // Track levels completed for interstitial ads
    levelsCompletedCount.current += 1;
    
    // Show interstitial every 3 levels
    if (levelsCompletedCount.current % 3 === 0) {
      ads.showInterstitial().catch(() => {});
    } else {
      // Pre-load next interstitial
      ads.prepareInterstitial().catch(() => {});
    }
  }, [currentLevelId]);

  const handleCheckpointTrap = useCallback(() => {
    setDeaths((d) => d + 1);
    setCurrentLevelId(1);
  }, []);

  const handleNextLevel = useCallback(() => {
    const nextId = Math.min(currentLevelId + 1, LEVELS.length);
    setCurrentLevelId(nextId);
    setControlIndicator(null);
    setScreen('playing');
  }, [currentLevelId]);

  if (screen === 'menu') {
    return (
      <MainMenu
        deaths={deaths}
        completed={completed}
        muted={muted}
        touchScale={touchScale}
        onMuteToggle={() => setMuted((m) => !m)}
        onTouchScaleChange={setTouchScale}
        onStart={handleStart}
        onCopyLink={copyLink}
        copyMsg={copyMsg}
      />
    );
  }

  return (
    <div className="relative min-h-screen w-full bg-[#05060a] text-white flex flex-col items-center p-1 sm:p-2" style={{ minHeight: '100vh' }}>
      {/* AdSense Banner for Web */}
      <AdBannerInit />
      <AdBanner className="hidden sm:block mb-2" />
      {/* HUD */}
      <div className="z-20 mb-2 flex w-full max-w-4xl flex-wrap items-center justify-between gap-2 px-2">
        <button
          onClick={() => setScreen('menu')}
          className="rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-semibold hover:bg-white/10"
        >
          ← Menu
        </button>
        <div className="flex items-center gap-2 text-center">
          <span className="text-[10px] uppercase tracking-widest text-slate-500">Lvl {level.id}</span>
          <span className="text-sm font-bold" style={{ color: level.accent }}>
            {level.name}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 rounded-full border border-red-400/30 bg-red-400/10 px-3 py-1.5">
            <span className="text-xs">💀</span>
            <span className="font-mono text-sm font-bold text-red-400">{deaths}</span>
          </div>
          <button
            onClick={() => setMuted((m) => !m)}
            className="rounded-lg border border-white/15 bg-white/5 px-2.5 py-1.5 text-xs hover:bg-white/10"
          >
            {muted ? '🔇' : '🔊'}
          </button>
        </div>
      </div>

      {controlIndicator && (
        <div className="z-20 mb-1 flex gap-3 rounded-lg border border-yellow-400/30 bg-yellow-400/10 px-3 py-1 text-[10px] font-mono text-yellow-300">
          <span>◀ = {controlIndicator.left.toUpperCase()}</span>
          <span>▶ = {controlIndicator.right.toUpperCase()}</span>
          <span>▲ = {controlIndicator.jump.toUpperCase()}</span>
        </div>
      )}

      <div className="w-full relative flex-1" style={{ maxWidth: '100vw', maxHeight: 'calc(100vh - 100px)' }}>
        <GameCanvas
          key={currentLevelId}
          level={level}
          muted={muted}
          touchRef={touchRef}
          onDeath={handleDeath}
          onComplete={handleComplete}
          onCheckpointTrap={handleCheckpointTrap}
          onControlIndicator={setControlIndicator}
        />
      </div>

      <p className="z-20 mt-2 text-[11px] text-slate-600 hidden sm:block">{level.subtitle}</p>

      <TouchControls touchRef={touchRef} scale={touchScale} visible={isTouchDevice} />

      {screen === 'levelComplete' && (
        <LevelCompleteOverlay
          level={level}
          deaths={deaths}
          onNext={handleNextLevel}
          onMenu={() => setScreen('menu')}
          onCopyLink={copyLink}
          copyMsg={copyMsg}
          isLast={isLastLevel}
        />
      )}
      {screen === 'victory' && (
        <VictoryOverlay deaths={deaths} onMenu={() => setScreen('menu')} onCopyLink={copyLink} copyMsg={copyMsg} />
      )}
    </div>
  );
}
