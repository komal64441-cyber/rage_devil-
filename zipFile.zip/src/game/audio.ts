// Lightweight synthesized audio engine (no external asset files needed).
// Provides SFX + a procedural looping BGM using the Web Audio API.

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private muted = false;
  private musicTimer: number | null = null;
  private musicStep = 0;
  private started = false;

  private ensureCtx() {
    if (!this.ctx) {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new Ctx();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 1;
      this.master.connect(this.ctx.destination);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.14;
      this.musicGain.connect(this.master);
      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 0.35;
      this.sfxGain.connect(this.master);
    }
    return this.ctx;
  }

  resume() {
    const ctx = this.ensureCtx();
    if (ctx.state === 'suspended') ctx.resume();
    if (!this.started) {
      this.started = true;
      this.startMusic();
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 1;
  }

  isMuted() {
    return this.muted;
  }

  private tone(freq: number, dur: number, type: OscillatorType = 'square', gainStart = 0.5, dest?: GainNode) {
    const ctx = this.ensureCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.value = gainStart;
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    osc.connect(gain);
    gain.connect(dest || this.sfxGain!);
    osc.start();
    osc.stop(ctx.currentTime + dur + 0.02);
  }

  jump() {
    this.tone(420, 0.14, 'square', 0.3);
    this.tone(620, 0.1, 'square', 0.15);
  }

  land() {
    this.tone(150, 0.08, 'triangle', 0.2);
  }

  death() {
    const ctx = this.ensureCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(320, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.45);
    gain.gain.value = 0.35;
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
    osc.connect(gain);
    gain.connect(this.sfxGain!);
    osc.start();
    osc.stop(ctx.currentTime + 0.55);
  }

  coin() {
    this.tone(880, 0.08, 'square', 0.2);
    setTimeout(() => this.tone(1180, 0.08, 'square', 0.15), 60);
  }

  fakeCoin() {
    this.tone(200, 0.3, 'sawtooth', 0.25);
  }

  flag() {
    [520, 660, 780, 1040].forEach((f, i) => setTimeout(() => this.tone(f, 0.18, 'square', 0.25), i * 90));
  }

  victory() {
    [523, 659, 784, 1046, 1318].forEach((f, i) => setTimeout(() => this.tone(f, 0.3, 'square', 0.25), i * 130));
  }

  click() {
    this.tone(500, 0.06, 'square', 0.2);
  }

  buzz() {
    this.tone(90, 0.4, 'sawtooth', 0.3);
  }

  teleport() {
    this.tone(1200, 0.05, 'sine', 0.2);
    this.tone(600, 0.15, 'sine', 0.15);
  }

  private startMusic() {
    const ctx = this.ensureCtx();
    const scale = [220, 246.94, 261.63, 293.66, 329.63, 349.23, 392, 440];
    const pattern = [0, 2, 4, 2, 5, 4, 2, 0, 3, 5, 7, 5, 4, 2, 1, 0];
    const stepTime = 0.22;

    const playStep = () => {
      if (!this.musicGain) return;
      const note = scale[pattern[this.musicStep % pattern.length] % scale.length];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = note;
      gain.gain.value = 0.0001;
      gain.gain.linearRampToValueAtTime(0.5, ctx.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + stepTime * 0.9);
      osc.connect(gain);
      gain.connect(this.musicGain);
      osc.start();
      osc.stop(ctx.currentTime + stepTime);

      if (this.musicStep % 4 === 0) {
        const bass = ctx.createOscillator();
        const bg = ctx.createGain();
        bass.type = 'sine';
        bass.frequency.value = note / 4;
        bg.gain.value = 0.0001;
        bg.gain.linearRampToValueAtTime(0.4, ctx.currentTime + 0.02);
        bg.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + stepTime * 1.8);
        bass.connect(bg);
        bg.connect(this.musicGain);
        bass.start();
        bass.stop(ctx.currentTime + stepTime * 2);
      }
      this.musicStep++;
    };

    this.musicTimer = window.setInterval(playStep, stepTime * 1000);
  }

  stopMusic() {
    if (this.musicTimer) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }
}

export const audio = new AudioEngine();
