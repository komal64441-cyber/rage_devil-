import type { Level, Platform, Hazard, Coin } from './types';

export const TILE = 44;
export const GROUND_Y = 460;
export const GROUND_H = 240;
export const VIEW_H = 540;

type Ov = Partial<Platform> | 'gap';

function corridor(count: number, overrides: Record<number, Ov> = {}, startX = 0, y = GROUND_Y, h = GROUND_H): Platform[] {
  const out: Platform[] = [];
  for (let i = 0; i < count; i++) {
    const o = overrides[i];
    if (o === 'gap') continue;
    const base: Platform = { x: startX + i * TILE, y, w: TILE, h, type: 'normal' };
    if (o && typeof o === 'object') Object.assign(base, o);
    out.push(base);
  }
  return out;
}

function plat(x: number, y: number, w: number, h: number, type: Platform['type'] = 'normal', extra: Partial<Platform> = {}): Platform {
  return { x, y, w, h, type, ...extra };
}

function spike(x: number, y: number, w = 30, h = 20): Hazard {
  return { x, y, w, h, type: 'spike' };
}

function ceilingSpike(x: number, triggerRadius = 130): Hazard {
  return { x, y: 40, w: 30, h: 28, type: 'ceilingSpike', triggerRadius };
}

function coin(x: number, y: number, fake = false): Coin {
  return { x, y, fake };
}

const levels: Level[] = [];

/* ------------------------------------------------------------------ */
/* WORLD 1 (1-5): THE PHYSICS TROLLS                                   */
/* ------------------------------------------------------------------ */

// Level 1 - The Basics
levels.push({
  id: 1,
  world: 1,
  name: 'The Basics',
  subtitle: 'Looks easy. It is not.',
  width: 1900,
  height: VIEW_H,
  spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(43, {
    9: { type: 'falling' },
    10: { type: 'falling' },
    22: { type: 'falling' },
    30: 'gap',
    31: 'gap',
  }),
  hazards: [ceilingSpike(700), ceilingSpike(1180), ceilingSpike(1500)],
  flag: { x: 1850, y: GROUND_Y - 70, runaway: true },
  mechanics: [],
  accent: '#22d3ee',
});

// Level 2 - The Illusion (REDESIGNED: visible path hidden in plain sight)
levels.push({
  id: 2,
  world: 1,
  name: 'The Illusion',
  subtitle: 'Some things are invisible until you touch them.',
  width: 1700,
  height: VIEW_H,
  spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: [
    ...corridor(8),
    // Bridge section: decorative platforms above + invisible platforms below (players see the illusion)
    plat(8 * TILE, GROUND_Y - 140, TILE * 8, 40, 'decorative'),
    // But the REAL path is invisible platforms at ground level
    plat(8 * TILE, GROUND_Y, TILE * 8, GROUND_H, 'invisible'),
    // Small jump up to visible safe zone
    ...corridor(8, {}, 16 * TILE),
    // Extended corridor to flag
    ...corridor(8, {}, 24 * TILE),
  ],
  hazards: [],
  coins: [
    coin(6 * TILE + 60, GROUND_Y - 60, true),
    coin(10 * TILE + 100, GROUND_Y - 180, false),
    coin(18 * TILE + 60, GROUND_Y - 60, false),
  ],
  flag: { x: 1620, y: GROUND_Y - 70 },
  mechanics: ['illusionMaze'],
  accent: '#a855f7',
});

// Level 3 - Gravity Chaos
levels.push({
  id: 3,
  world: 1,
  name: 'Gravity Chaos',
  subtitle: 'Up is down. Down is up.',
  width: 2000,
  height: VIEW_H,
  spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: [
    ...corridor(10),
    ...corridor(8, {}, 10 * TILE, 60, 200),
    ...corridor(6, {}, 18 * TILE),
    ...corridor(8, {}, 24 * TILE, 60, 200),
    ...corridor(10, {}, 32 * TILE),
    plat(11 * TILE, 300, TILE, 30),
    plat(13 * TILE, 300, TILE, 30),
    plat(25 * TILE, 300, TILE, 30),
    plat(27 * TILE, 300, TILE, 30),
  ],
  hazards: [spike(15 * TILE, GROUND_Y - 20), spike(29 * TILE, GROUND_Y - 20)],
  gravityZones: [
    { x: 9.5 * TILE, y: 0, w: 20, h: VIEW_H },
    { x: 17.5 * TILE, y: 0, w: 20, h: VIEW_H },
    { x: 23.5 * TILE, y: 0, w: 20, h: VIEW_H },
    { x: 31.5 * TILE, y: 0, w: 20, h: VIEW_H },
  ],
  flag: { x: 1960, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#f472b6',
});

// Level 4 - The Runaway
levels.push({
  id: 4,
  world: 1,
  name: 'The Runaway',
  subtitle: 'It does not want to be caught.',
  width: 1900,
  height: VIEW_H,
  spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: [
    ...corridor(43, { 20: 'gap', 21: 'gap', 38: { type: 'falling' }, 39: { type: 'falling' } }),
    plat(700, GROUND_Y - 30, 80, 30, 'moving', { moveAxis: 'x', moveRange: 160, moveSpeed: 2.4 }),
    plat(1100, GROUND_Y - 140, 80, 30, 'moving', { moveAxis: 'x', moveRange: 140, moveSpeed: 3.1 }),
    plat(1400, GROUND_Y - 30, 80, 30, 'moving', { moveAxis: 'x', moveRange: 160, moveSpeed: 2.7 }),
  ],
  hazards: [spike(35 * TILE, GROUND_Y - 20)],
  flag: { x: 1850, y: GROUND_Y - 70, runaway: true },
  mechanics: [],
  accent: '#fb923c',
});

// Level 5 - The Ultimate Troll
levels.push({
  id: 5,
  world: 1,
  name: 'The Ultimate Troll',
  subtitle: 'Your own keys betray you.',
  width: 1700,
  height: VIEW_H,
  spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(38, { 14: 'gap', 15: 'gap', 26: 'gap' }),
  hazards: [spike(9 * TILE, GROUND_Y - 20), spike(30 * TILE, GROUND_Y - 20)],
  flag: { x: 1650, y: GROUND_Y - 70 },
  mechanics: ['keyScramble'],
  accent: '#facc15',
});

/* ------------------------------------------------------------------ */
/* WORLD 2 (6-15): VISUAL & ENVIRONMENTAL GASLIGHTING                  */
/* ------------------------------------------------------------------ */

levels.push({
  id: 6, world: 2, name: 'Fake UI', subtitle: 'Not a real pop-up. Or is it?',
  width: 1700, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(38, { 16: 'gap' }),
  hazards: [ceilingSpike(800, 150), spike(15 * TILE, GROUND_Y - 20)],
  flag: { x: 1650, y: GROUND_Y - 70 },
  mechanics: ['fakePopup'],
  accent: '#38bdf8',
});

levels.push({
  id: 7, world: 2, name: 'The Floor is Fake', subtitle: 'Only the air is solid.',
  width: 1700, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: [
    ...corridor(6),
    ...corridor(24, {}, 6 * TILE).map((p) => ({ ...p, type: 'decorative' as const })),
    plat(6 * TILE, GROUND_Y - 60, 900, 8, 'invisible'),
    ...corridor(8, {}, 30 * TILE),
  ],
  hazards: [],
  flag: { x: 1650, y: GROUND_Y - 70 },
  mechanics: ['illusionMaze'],
  accent: '#4ade80',
});

levels.push({
  id: 8, world: 2, name: 'Reverse Momentum', subtitle: 'Everything is inverted.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(34),
  hazards: [ceilingSpike(9 * TILE, 140), ceilingSpike(24 * TILE, 140)],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['reverseControls'],
  accent: '#f87171',
});

levels.push({
  id: 9, world: 2, name: 'Lag Simulator', subtitle: 'Your inputs arrive late.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(34, { 10: 'gap', 20: 'gap' }),
  hazards: [spike(24 * TILE, GROUND_Y - 20)],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['inputLag'],
  accent: '#60a5fa',
});

levels.push({
  id: 10, world: 2, name: 'The Shrinking Window', subtitle: 'The world closes in.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(36, { 14: 'gap', 26: 'gap' }),
  hazards: [spike(16 * TILE, GROUND_Y - 20)],
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: ['shrinkWindow'],
  accent: '#fde047',
});

levels.push({
  id: 11, world: 2, name: 'Bouncy Castles', subtitle: 'Spring-loaded danger.',
  width: 1700, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(38, {
    8: { type: 'bouncy' },
    9: { type: 'bouncy' },
    24: { type: 'bouncy' },
  }),
  hazards: [spike(12 * TILE, GROUND_Y - 20), spike(27 * TILE, GROUND_Y - 20)],
  flag: { x: 1650, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#fb7185',
});

levels.push({
  id: 12, world: 2, name: 'Troll Checkpoint', subtitle: 'Safety is a lie.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(34, { 16: 'gap' }),
  hazards: [],
  checkpoint: { x: 18 * TILE, y: GROUND_Y - 60 },
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['checkpointTroll'],
  accent: '#34d399',
});

levels.push({
  id: 13, world: 2, name: 'The Sound Barrier', subtitle: 'Deafening disruption.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(34, { 14: 'gap', 24: 'gap' }),
  hazards: [spike(16 * TILE, GROUND_Y - 20)],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['soundBarrier'],
  accent: '#f472b6',
});

levels.push({
  id: 14, world: 2, name: "Schrodinger's Blocks", subtitle: 'Only solid if unseen.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(36, { 18: 'gap' }),
  hazards: [ceilingSpike(8 * TILE, 140), ceilingSpike(25 * TILE, 140)],
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#93c5fd',
});

/* ------------------------------------------------------------------ */
/* WORLD 3 (15-24): EXTREME GEOMETRY & PRECISION HELL                  */
/* ------------------------------------------------------------------ */

levels.push({
  id: 15, world: 3, name: 'The Conveyor Belt', subtitle: 'It changes direction.',
  width: 1700, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: [
    ...corridor(10),
    ...corridor(14, {}, 10 * TILE).map((p) => ({ ...p, type: 'conveyor' as const, conveyorDir: 1 as const })),
    ...corridor(14, {}, 24 * TILE),
  ],
  hazards: [spike(23 * TILE, GROUND_Y - 20)],
  flag: { x: 1650, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#2dd4bf',
});

levels.push({
  id: 16, world: 3, name: 'The Maze Runner', subtitle: 'The ceiling descends.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(36, { 16: 'gap', 26: 'gap' }),
  hazards: [spike(18 * TILE, GROUND_Y - 20), spike(28 * TILE, GROUND_Y - 20)],
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: ['lowCeiling'],
  lowCeilingZones: [{ x: 300, y: 0, w: 1300, h: 220, maxJump: 90 }],
  accent: '#a3e635',
});

levels.push({
  id: 17, world: 3, name: 'Sudden Teleports', subtitle: 'Landing has consequences.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(36, {
    12: { type: 'teleport' },
    22: { type: 'teleport' },
    33: { type: 'falling' },
    34: { type: 'falling' },
  }),
  hazards: [ceilingSpike(8 * TILE, 140), spike(25 * TILE, GROUND_Y - 20)],
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#f97316',
});

levels.push({
  id: 18, world: 3, name: 'The Fake Ending', subtitle: 'You did not win.',
  width: 1400, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(30, { 12: 'gap' }),
  hazards: [],
  flag: { x: 1310, y: GROUND_Y - 70 },
  mechanics: ['fakeEnding'],
  accent: '#eab308',
});

levels.push({
  id: 19, world: 3, name: 'Wind Tunnel', subtitle: 'Constant push-back.',
  width: 1700, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(38, { 20: 'gap', 35: { type: 'falling' }, 36: { type: 'falling' } }),
  hazards: [spike(22 * TILE, GROUND_Y - 20), ceilingSpike(14 * TILE, 140)],
  windZones: [{ x: 400, y: 0, w: 1000, h: VIEW_H, force: -0.35 }],
  flag: { x: 1650, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#7dd3fc',
});

levels.push({
  id: 20, world: 3, name: 'Bullet Hell', subtitle: 'Turrets fire relentlessly.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(36, { 18: 'gap' }),
  hazards: [{ x: 0, y: 0, w: 30, h: 30, type: 'turret' }, { x: 1560, y: 0, w: 30, h: 30, type: 'turret' }],
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#f43f5e',
});

levels.push({
  id: 21, world: 3, name: 'Size Matters', subtitle: 'Sudden growth.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(36, { 20: 'gap', 33: { type: 'falling' }, 34: { type: 'falling' } }),
  hazards: [spike(10 * TILE, GROUND_Y - 20), ceilingSpike(28 * TILE, 140)],
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: ['sizeChangeRandom'],
  accent: '#fbbf24',
});

levels.push({
  id: 22, world: 3, name: 'The Slope Paradox', subtitle: 'Gravity is backwards here.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: [
    ...corridor(10),
    plat(10 * TILE, GROUND_Y, TILE, GROUND_H, 'slope'),
    ...corridor(12, {}, 12 * TILE),
    plat(24 * TILE, GROUND_Y, TILE, GROUND_H, 'slope'),
    ...corridor(10, {}, 26 * TILE, GROUND_Y, GROUND_H),
    plat(30 * TILE, 260, TILE * 2, 30),
    plat(32 * TILE, GROUND_Y, TILE, GROUND_H, 'falling'),
    plat(33 * TILE, GROUND_Y, TILE, GROUND_H, 'falling'),
  ],
  hazards: [spike(15 * TILE, GROUND_Y - 20), ceilingSpike(6 * TILE, 140)],
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#5eead4',
});

levels.push({
  id: 23, world: 3, name: 'Vanishing Acts', subtitle: 'Platforms blink away.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(34, { 16: 'gap', 30: { type: 'falling' }, 31: { type: 'falling' } }),
  hazards: [ceilingSpike(8 * TILE, 140), spike(20 * TILE, GROUND_Y - 20)],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['ghostFloor'],
  accent: '#fca5a5',
});

levels.push({
  id: 24, world: 3, name: 'The Intermittent Light', subtitle: 'Periodic darkness.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(34, { 14: 'gap', 24: 'gap' }),
  hazards: [spike(16 * TILE, GROUND_Y - 20)],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['blackoutFlicker'],
  accent: '#e2e8f0',
});

/* ------------------------------------------------------------------ */
/* WORLD 4 (25-34): THE ULTIMATE RAGE SUITE                             */
/* ------------------------------------------------------------------ */

levels.push({
  id: 25, world: 4, name: 'The Low Ceiling', subtitle: 'Space is limited.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(34, { 14: 'gap' }),
  hazards: [],
  lowCeilingZones: [{ x: 0, y: 0, w: 1500, h: 260, maxJump: 70 }],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['lowCeiling'],
  accent: '#d8b4fe',
});

levels.push({
  id: 26, world: 4, name: 'Double Jump Deception', subtitle: 'Second jump destroys ground.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(34, { 16: 'gap' }),
  hazards: [],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['doubleJumpDestroysFloor'],
  accent: '#67e8f9',
});

levels.push({
  id: 27, world: 4, name: 'Ice Age', subtitle: 'No friction. Infinite momentum.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(36, { 18: 'gap' }),
  hazards: [spike(20 * TILE, GROUND_Y - 20)],
  friction: 1,
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#bae6fd',
});

levels.push({
  id: 28, world: 4, name: 'The Chase', subtitle: 'Something pursues you.',
  width: 1800, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(41, { 20: 'gap' }),
  hazards: [],
  flag: { x: 1750, y: GROUND_Y - 70 },
  mechanics: ['chaseWall'],
  accent: '#f87171',
});

levels.push({
  id: 29, world: 4, name: 'Pixel Perfect', subtitle: 'Sub-pixel precision required.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(34, { 12: 'gap', 22: 'gap' }),
  hazards: [spike(14 * TILE, GROUND_Y - 20)],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['pixelPerfect'],
  accent: '#fda4af',
});

levels.push({
  id: 30, world: 4, name: 'The Quiz Level', subtitle: 'Answer incorrectly to fall.',
  width: 1500, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: [
    ...corridor(8),
    plat(8 * TILE, GROUND_Y - 20, 100, 20, 'quiz', { label: '4', correct: false }),
    plat(8 * TILE + 140, GROUND_Y - 20, 100, 20, 'quiz', { label: '5', correct: true }),
    ...corridor(10, {}, 12 * TILE),
    plat(12 * TILE + 220, GROUND_Y - 20, 100, 20, 'quiz', { label: '9', correct: true }),
    plat(12 * TILE + 360, GROUND_Y - 20, 100, 20, 'quiz', { label: '8', correct: false }),
    ...corridor(10, {}, 18 * TILE),
    plat(28 * TILE, GROUND_Y, TILE, GROUND_H, 'falling'),
    plat(29 * TILE, GROUND_Y, TILE, GROUND_H, 'falling'),
  ],
  hazards: [ceilingSpike(14 * TILE, 140), spike(25 * TILE, GROUND_Y - 20)],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: [],
  accent: '#fef08a',
});

levels.push({
  id: 31, world: 4, name: 'Slow Motion Trap', subtitle: 'Time slows on jump.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(36, { 16: 'gap', 26: 'gap' }),
  hazards: [spike(18 * TILE, GROUND_Y - 20)],
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: ['slowMotionOnJump'],
  accent: '#c7d2fe',
});

levels.push({
  id: 32, world: 4, name: 'Ghost Inputs', subtitle: 'Random phantom commands.',
  width: 1600, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: corridor(36, { 18: 'gap' }),
  hazards: [spike(10 * TILE, GROUND_Y - 20)],
  flag: { x: 1550, y: GROUND_Y - 70 },
  mechanics: ['ghostInputs'],
  accent: '#d9f99d',
});

levels.push({
  id: 33, world: 4, name: 'The False Boundary', subtitle: 'Cannot go back.',
  width: 1500, height: VIEW_H, spawn: { x: 60, y: GROUND_Y - 40 },
  platforms: corridor(34, { 16: 'gap', 30: { type: 'falling' }, 31: { type: 'falling' } }),
  hazards: [ceilingSpike(10 * TILE, 140), spike(22 * TILE, GROUND_Y - 20)],
  flag: { x: 1450, y: GROUND_Y - 70 },
  mechanics: ['falseBoundaryDeath'],
  accent: '#fca5a5',
});

levels.push({
  id: 34, world: 4, name: 'The Final Screen', subtitle: 'Everything awaits.',
  width: 2200, height: VIEW_H, spawn: { x: 40, y: GROUND_Y - 40 },
  platforms: [
    ...corridor(12, { 5: { type: 'falling' }, 9: 'gap' }),
    ...corridor(8, {}, 12 * TILE, 60, 200),
    ...corridor(10, {}, 20 * TILE, GROUND_Y, GROUND_H),
    plat(13 * TILE, 300, TILE, 30),
    plat(15 * TILE, 300, TILE, 30),
    plat(17 * TILE, 300, TILE, 30),
    ...corridor(8, {}, 30 * TILE, GROUND_Y, GROUND_H),
    ...corridor(12, {}, 38 * TILE, GROUND_Y, GROUND_H),
  ],
  hazards: [ceilingSpike(1100), spike(31 * TILE, GROUND_Y - 20)],
  gravityZones: [
    { x: 11.5 * TILE, y: 0, w: 20, h: VIEW_H },
    { x: 19.5 * TILE, y: 0, w: 20, h: VIEW_H },
  ],
  flag: { x: 2140, y: GROUND_Y },
  mechanics: ['keyScramble', 'finalGauntlet'],
  accent: '#f0abfc',
});

export const LEVELS: Level[] = levels;

export const WORLDS = [
  { world: 1, title: 'World 1 — The Physics Trolls' },
  { world: 2, title: 'World 2 — Visual & Environmental Gaslighting' },
  { world: 3, title: 'World 3 — Extreme Geometry & Precision Hell' },
  { world: 4, title: 'World 4 — The Ultimate Rage Suite' },
];
