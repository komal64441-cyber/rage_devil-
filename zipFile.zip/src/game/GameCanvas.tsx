import { useEffect, useRef, useState, useCallback } from 'react';
import type { Level, Platform, Hazard } from './types';
import { audio } from './audio';

export const VIEW_W = 960;
export const VIEW_H = 540;

type Action = 'left' | 'right' | 'jump';

interface RuntimePlatform extends Platform {
  baseX: number;
  baseY: number;
  removed: boolean;
  falling: boolean;
  fallVy: number;
  moveT: number;
  prevMoveX: number;
  quizBroken: boolean;
  vanishUntil: number;
}

interface RuntimeHazard extends Hazard {
  state: 'idle' | 'dropping' | 'gone';
  curY: number;
  triggered: boolean;
}

interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  born: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  size: number;
  color: string;
}

export interface TouchState {
  left: boolean;
  right: boolean;
  jump: boolean;
}

export interface ControlIndicator {
  left: Action;
  right: Action;
  jump: Action;
  reversed: boolean;
}

interface Props {
  level: Level;
  muted: boolean;
  touchRef: React.MutableRefObject<TouchState>;
  onDeath: () => void;
  onComplete: () => void;
  onCheckpointTrap: () => void;
  onControlIndicator?: (c: ControlIndicator | null) => void;
}

const GRAVITY = 0.62;
const JUMP_V = -12.6;
const MOVE_ACCEL = 0.85;
const MAX_SPEED = 4.6;
const DEFAULT_FRICTION = 0.78;

function rectsOverlap(a: { x: number; y: number; w: number; h: number }, b: { x: number; y: number; w: number; h: number }) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

export default function GameCanvas({ level, muted, touchRef, onDeath, onComplete, onCheckpointTrap, onControlIndicator }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [popup, setPopup] = useState<{ visible: boolean } | null>(null);
  const [fakeEndOverlay, setFakeEndOverlay] = useState(false);
  const [checkpointMsg, setCheckpointMsg] = useState(false);
  const [cropInset, setCropInset] = useState(0);
  const [warningFlash, setWarningFlash] = useState(false);

  const keysDown = useRef<Record<string, boolean>>({});

  useEffect(() => {
    audio.setMuted(muted);
  }, [muted]);

  const stateRef = useRef<any>(null);

  const buildRuntime = useCallback((lvl: Level) => {
    const platforms: RuntimePlatform[] = lvl.platforms.map((p) => ({
      ...p,
      baseX: p.x,
      baseY: p.y,
      removed: false,
      falling: false,
      fallVy: 0,
      moveT: Math.random() * 10,
      prevMoveX: p.x,
      quizBroken: false,
      vanishUntil: 0,
    }));
    const hazards: RuntimeHazard[] = lvl.hazards.map((h) => ({ ...h, state: 'idle', curY: h.y, triggered: false }));
    const coins = (lvl.coins || []).map((c) => ({ ...c, collected: false }));
    const zones = (lvl.gravityZones || []).map((z) => ({ ...z, armed: true }));
    return {
      player: {
        x: lvl.spawn.x,
        y: lvl.spawn.y,
        w: 30,
        h: 30,
        vx: 0,
        vy: 0,
        grounded: false,
        facing: 1 as 1 | -1,
        gravityDir: 1 as 1 | -1,
        jumpsUsed: 0,
        maxJumps: lvl.mechanics.includes('doubleJumpDestroysFloor') ? 2 : 1,
        sizeMul: 1,
      },
      platforms,
      hazards,
      coins,
      zones,
      bullets: [] as Bullet[],
      particles: [] as Particle[],
      flag: { x: lvl.flag.x, y: lvl.flag.y },
      camera: { x: 0 },
      shake: 0,
      time: 0,
      groundedPlatform: null as RuntimePlatform | null,
      prevJumpEdge: false,
      controlMap: { left: 'left' as Action, right: 'right' as Action, jump: 'jump' as Action },
      lastScramble: 0,
      inputBuffer: [] as { t: number; left: boolean; right: boolean; jump: boolean }[],
      lagActive: false,
      lagNextToggle: 2500 + Math.random() * 2500,
      ghostActive: { left: false, jump: false },
      ghostNextTrigger: 2000 + Math.random() * 3000,
      ghostUntil: 0,
      jumpCount: 0,
      sizeTimer: 0,
      sizeUntil: 0,
      timeScale: 1,
      timeScaleUntil: 0,
      conveyorDir: 1,
      conveyorNextFlip: 2500 + Math.random() * 2000,
      blackoutTimer: 0,
      blackoutOn: false,
      popupShown: false,
      soundBarrierShown: false,
      chaseWallX: -50,
      fakeEndTricked: false,
      vanishQueue: [] as { plat: RuntimePlatform; restoreAt: number }[],
      phantomInputBuffer: [] as { t: number; x: number; vy: number }[],
      lastWalkParticle: 0,
      dead: false,
      done: false,
    };
  }, []);

  useEffect(() => {
    stateRef.current = buildRuntime(level);
    setPopup(null);
    setFakeEndOverlay(false);
    setCheckpointMsg(false);
    setCropInset(0);
    setWarningFlash(false);
    if (onControlIndicator) onControlIndicator(null);
  }, [level, buildRuntime, onControlIndicator]);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      keysDown.current[e.key.toLowerCase()] = true;
      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(e.key.toLowerCase())) e.preventDefault();
      audio.resume();
    };
    const up = (e: KeyboardEvent) => {
      keysDown.current[e.key.toLowerCase()] = false;
    };
    window.addEventListener('keydown', down, { passive: false });
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let raf = 0;
    let last = performance.now();

    const respawn = () => {
      const s = stateRef.current;
      const fresh = buildRuntime(level);
      fresh.fakeEndTricked = s.fakeEndTricked;
      stateRef.current = fresh;
      setPopup(null);
      setWarningFlash(false);
      setCropInset(0);
      if (onControlIndicator) onControlIndicator(null);
    };

    const die = () => {
      const s = stateRef.current;
      if (s.dead || s.done) return;
      s.dead = true;
      audio.death();
      onDeath();
      setTimeout(respawn, 260);
    };

    const has = (m: string) => level.mechanics.includes(m as any);

    const loop = (now: number) => {
      const rawDt = Math.min((now - last) / 16.6667, 2.2);
      last = now;
      const s = stateRef.current;
      if (s && !s.dead && !s.done) {
        update(s, rawDt, now);
      }
      render(ctx, s, now);
      raf = requestAnimationFrame(loop);
    };

    const update = (s: any, rawDt: number, now: number) => {
      s.time += rawDt * 16.6667;

      const spawnParticle = (x: number, y: number, vx: number, vy: number, life = 22, size = 2.8, color = level.accent || '#22d3ee') => {
        s.particles.push({ x, y, vx, vy, life, size, color });
      };

      // ---- key scramble ----
      if (has('keyScramble')) {
        if (now - s.lastScramble > 5000) {
          s.lastScramble = now;
          const actions: Action[] = ['left', 'right', 'jump'];
          for (let i = actions.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [actions[i], actions[j]] = [actions[j], actions[i]];
          }
          s.controlMap = { left: actions[0], right: actions[1], jump: actions[2] };
          audio.click();
          if (onControlIndicator) onControlIndicator({ ...s.controlMap, reversed: false });
        }
      } else if (has('reverseControls')) {
        s.controlMap = { left: 'right', right: 'left', jump: 'jump' };
      } else {
        s.controlMap = { left: 'left', right: 'right', jump: 'jump' };
      }

      // ---- raw input ----
      const kd = keysDown.current;
      const t = touchRef.current;
      const rawLeft = !!(kd['arrowleft'] || kd['a'] || t.left);
      const rawRight = !!(kd['arrowright'] || kd['d'] || t.right);
      const rawJump = !!(kd['arrowup'] || kd['w'] || kd[' '] || t.jump);

      // ---- ghost inputs ----
      if (has('ghostInputs')) {
        if (now > s.ghostUntil && s.time > s.ghostNextTrigger) {
          const dur = 160 + Math.random() * 180;
          s.ghostUntil = now + dur;
          s.ghostActive = { left: Math.random() < 0.5, jump: Math.random() < 0.5 };
          s.ghostNextTrigger = s.time + 2200 + Math.random() * 3200;
        }
        if (now > s.ghostUntil) s.ghostActive = { left: false, jump: false };
      }

      let effLeft = rawLeft || (has('ghostInputs') && s.ghostActive.left);
      let effRight = rawRight;
      let effJump = rawJump || (has('ghostInputs') && s.ghostActive.jump);

      // ---- input lag ----
      s.inputBuffer.push({ t: now, left: effLeft, right: effRight, jump: effJump });
      while (s.inputBuffer.length > 240) s.inputBuffer.shift();
      if (has('inputLag')) {
        if (s.time > s.lagNextToggle) {
          s.lagActive = !s.lagActive;
          s.lagNextToggle = s.time + (s.lagActive ? 1800 : 3200 + Math.random() * 2000);
        }
        if (s.lagActive) {
          const target = now - 500;
          let snap = s.inputBuffer[0];
          for (const entry of s.inputBuffer) {
            if (entry.t <= target) snap = entry;
            else break;
          }
          effLeft = snap.left;
          effRight = snap.right;
          effJump = snap.jump;
        }
      }

      // ---- map to actions ----
      const actionsHeld: Record<Action, boolean> = { left: false, right: false, jump: false };
      const cmLeft: Action = s.controlMap.left;
      const cmRight: Action = s.controlMap.right;
      const cmJump: Action = s.controlMap.jump;
      actionsHeld[cmLeft] = actionsHeld[cmLeft] || effLeft;
      actionsHeld[cmRight] = actionsHeld[cmRight] || effRight;
      actionsHeld[cmJump] = actionsHeld[cmJump] || effJump;

      const p = s.player;

      // ---- time scale (slow motion trap) ----
      if (has('slowMotionOnJump')) {
        if (now < s.timeScaleUntil) {
          s.timeScale += (1 - s.timeScale) * 0.02;
        } else {
          s.timeScale += (1 - s.timeScale) * 0.08;
        }
      } else {
        s.timeScale = 1;
      }
      const dt = rawDt * s.timeScale;

      // ---- horizontal movement ----
      const friction = level.friction ?? DEFAULT_FRICTION;
      let moveDir = 0;
      if (actionsHeld.left) moveDir -= 1;
      if (actionsHeld.right) moveDir += 1;
      if (moveDir !== 0) {
        p.vx += moveDir * MOVE_ACCEL * dt;
        p.vx = Math.max(-MAX_SPEED, Math.min(MAX_SPEED, p.vx));
        p.facing = moveDir > 0 ? 1 : -1;
      } else if (p.grounded) {
        p.vx *= Math.pow(friction, dt);
      }

      // wind zones
      for (const wz of level.windZones || []) {
        if (rectsOverlap(p, wz)) p.vx += wz.force * dt;
      }

      // conveyor global flip
      if (s.time > s.conveyorNextFlip) {
        s.conveyorDir *= -1;
        s.conveyorNextFlip = s.time + 2600 + Math.random() * 2400;
      }

      // ---- jump handling ----
      const jumpEdge = actionsHeld.jump && !s.prevJumpEdge;
      s.prevJumpEdge = actionsHeld.jump;

      if (jumpEdge && p.jumpsUsed < p.maxJumps) {
        p.vy = JUMP_V * p.gravityDir;
        p.jumpsUsed += 1;
        p.grounded = false;
        audio.jump();
        // Jump burst particles
        for (let i = 0; i < 8; i++) {
          const spread = (Math.random() - 0.5) * 2.6;
          spawnParticle(p.x + p.w / 2, p.y + p.h, spread, 1.2 + Math.random() * 1.8, 24, 2.4, '#e2e8f0');
        }
        s.jumpCount += 1;
        if (has('shrinkWindow')) setCropInset(Math.min(160, s.jumpCount * 12));
        if (has('slowMotionOnJump')) {
          s.timeScaleUntil = now + 900;
          s.timeScale = 0.32;
        }
        if (has('ghostFloor') && s.groundedPlatform) {
          s.vanishQueue.push({ plat: s.groundedPlatform, restoreAt: -1 });
        }
        if (has('doubleJumpDestroysFloor') && p.jumpsUsed === 2 && s.groundedPlatform) {
          s.groundedPlatform.removed = true;
        }
      }

      // ---- gravity ----
      p.vy += GRAVITY * p.gravityDir * dt;
      const maxFall = 15;
      p.vy = Math.max(-maxFall, Math.min(maxFall, p.vy));

      // ---- schrodinger solidity ----
      const schrodingerSolidNow = !effRight;

      // ---- move + collide X ----
      p.x += p.vx * dt;
      p.grounded = false;
      s.groundedPlatform = null;

      const solidPlatforms = s.platforms.filter((pl: RuntimePlatform) => {
        if (pl.removed || pl.falling) return false;
        if (pl.type === 'decorative') return false;
        if (pl.type === 'schrodinger' && !schrodingerSolidNow) return false;
        if (now < pl.vanishUntil) return false;
        return true;
      });

      const box = () => ({ x: p.x - (p.sizeMul - 1) * 15, y: p.y - (p.sizeMul - 1) * 15, w: p.w * p.sizeMul, h: p.h * p.sizeMul });

      for (const pl of solidPlatforms) {
        const b = box();
        if (!rectsOverlap(b, pl)) continue;
        const overlapX = Math.min(b.x + b.w, pl.x + pl.w) - Math.max(b.x, pl.x);
        if (b.x < pl.x) {
          p.x -= overlapX;
          if (pl.type === 'bouncy') p.vx = -p.vx * 0.85;
          else p.vx = 0;
        } else {
          p.x += overlapX;
          if (pl.type === 'bouncy') p.vx = -p.vx * 0.85;
          else p.vx = 0;
        }
      }

      // Walking particles when grounded and moving
      if (p.grounded && Math.abs(p.vx) > 0.7 && now - s.lastWalkParticle > 60) {
        s.lastWalkParticle = now;
        const dir = p.vx > 0 ? -1 : 1;
        spawnParticle(p.x + p.w / 2, p.y + p.h - 2, dir * (0.6 + Math.random() * 0.8), -0.4 - Math.random() * 0.6, 18, 2, '#94a3b8');
      }

      // ---- move + collide Y ----
      p.y += p.vy * dt;
      for (const pl of solidPlatforms) {
        const b = box();
        if (!rectsOverlap(b, pl)) continue;
        const overlapY = Math.min(b.y + b.h, pl.y + pl.h) - Math.max(b.y, pl.y);
        const landedTop = b.y < pl.y;
        if (landedTop) {
          p.y -= overlapY;
          if (pl.type === 'bouncy' && p.vy > 2) {
            p.vy = -p.vy * 0.85;
          } else {
            p.vy = 0;
          }
          if (p.gravityDir === 1 && pl.type !== 'bouncy') {
            p.grounded = true;
            p.jumpsUsed = 0;
            s.groundedPlatform = pl;
            handleLanding(s, pl, now);
          } else if (p.gravityDir === 1 && pl.type === 'bouncy') {
            // bounced, not grounded
          } else if (p.gravityDir === -1) {
            // hit underside while flipped - just a bonk
          }
        } else {
          p.y += overlapY;
          if (pl.type === 'bouncy' && p.vy < -2) {
            p.vy = -p.vy * 0.85;
          } else {
            p.vy = 0;
          }
          if (p.gravityDir === -1 && pl.type !== 'bouncy') {
            p.grounded = true;
            p.jumpsUsed = 0;
            s.groundedPlatform = pl;
            handleLanding(s, pl, now);
          }
        }
      }

      // ---- moving platforms carry player ----
      for (const pl of s.platforms) {
        if (pl.type === 'moving' && !pl.removed) {
          pl.moveT += 0.02 * dt * (pl.moveSpeed || 2);
          const newX = pl.baseX + Math.sin(pl.moveT) * (pl.moveRange || 100);
          const dx = newX - pl.x;
          pl.x = newX;
          if (s.groundedPlatform === pl) p.x += dx;
        }
        if (pl.type === 'conveyor' && !pl.removed && s.groundedPlatform === pl) {
          p.vx += s.conveyorDir * 0.6 * dt;
          p.vx = Math.max(-MAX_SPEED * 1.6, Math.min(MAX_SPEED * 1.6, p.vx));
        }
        if (pl.falling) {
          pl.fallVy += 0.5 * dt;
          pl.y += pl.fallVy * dt;
        }
      }

      // process vanish queue (ghostFloor)
      if (has('ghostFloor')) {
        for (const item of s.vanishQueue) {
          if (item.restoreAt === -1) {
            item.restoreAt = now + 500;
          } else if (item.restoreAt > 0 && now >= item.restoreAt && item.restoreAt < now + 100000) {
            if (item.restoreAt !== -2) {
              item.plat.vanishUntil = now + 1300;
              item.restoreAt = -2;
            }
          }
        }
        s.vanishQueue = s.vanishQueue.filter((it: any) => it.restoreAt !== -2 || it.plat.vanishUntil > now);
      }

      // ---- size change ----
      if (has('sizeChangeRandom')) {
        if (now > s.sizeUntil && s.time > s.sizeTimer) {
          s.sizeUntil = now + 2200;
          p.sizeMul = 1.9;
          s.sizeTimer = s.time + 4500 + Math.random() * 3000;
        } else if (now > s.sizeUntil) {
          p.sizeMul = 1;
        }
      }

      // ---- gravity zones ----
      for (const z of s.zones) {
        const overlap = rectsOverlap(p, z);
        if (overlap && z.armed) {
          p.gravityDir *= -1;
          z.armed = false;
          audio.teleport();
        } else if (!overlap) {
          z.armed = true;
        }
      }

      // ---- low ceiling zones ----
      for (const z of level.lowCeilingZones || []) {
        if (p.x + p.w > z.x && p.x < z.x + z.w) {
          const limitY = p.gravityDir === 1 ? 460 - z.maxJump : 40 + z.maxJump;
          if (p.gravityDir === 1 && p.y < limitY) {
            p.y = limitY;
            if (p.vy < 0) p.vy = 0;
          } else if (p.gravityDir === -1 && p.y > limitY) {
            p.y = limitY;
            if (p.vy > 0) p.vy = 0;
          }
        }
      }

      // ---- pixel perfect hazard padding ----
      const hazardPad = has('pixelPerfect') ? 5 : 0;

      // ---- ceiling spikes ----
      for (const hz of s.hazards) {
        if (hz.type === 'ceilingSpike') {
          if (hz.state === 'idle') {
            const dx = Math.abs(p.x + p.w / 2 - (hz.x + hz.w / 2));
            if (dx < (hz.triggerRadius || 120)) {
              hz.state = 'dropping';
              hz.triggered = true;
            }
          } else if (hz.state === 'dropping') {
            hz.curY += 13 * dt;
            const hb = { x: hz.x - hazardPad, y: hz.curY - hazardPad, w: hz.w + hazardPad * 2, h: hz.h + hazardPad * 2 };
            if (rectsOverlap(box(), hb)) {
              die();
              return;
            }
            if (hz.curY > level.height + 200) hz.state = 'gone';
          }
        } else if (hz.type === 'spike') {
          const hb = { x: hz.x - hazardPad, y: hz.y - hazardPad, w: hz.w + hazardPad * 2, h: hz.h + hazardPad * 2 };
          if (rectsOverlap(box(), hb)) {
            die();
            return;
          }
        }
      }

      // ---- turret bullets ----
      const hasTurret = level.hazards.some((h) => h.type === 'turret');
      if (hasTurret) {
        if (!s._nextBullet || s.time > s._nextBullet) {
          s._nextBullet = s.time + 1400;
          const corners = [
            { x: s.camera.x + 20, y: 20 },
            { x: s.camera.x + VIEW_W - 20, y: 20 },
            { x: s.camera.x + 20, y: VIEW_H - 20 },
            { x: s.camera.x + VIEW_W - 20, y: VIEW_H - 20 },
          ];
          for (const c of corners) {
            const dx = p.x - c.x;
            const dy = p.y - c.y;
            const len = Math.max(1, Math.hypot(dx, dy));
            s.bullets.push({ x: c.x, y: c.y, vx: (dx / len) * 2.1, vy: (dy / len) * 2.1, born: s.time });
          }
        }
        for (const b of s.bullets) {
          b.x += b.vx * dt;
          b.y += b.vy * dt;
        }
        s.bullets = s.bullets.filter((b: Bullet) => s.time - b.born < 6000);
        for (const b of s.bullets) {
          if (rectsOverlap(box(), { x: b.x - 8, y: b.y - 8, w: 16, h: 16 })) {
            die();
            return;
          }
        }
      }

      // ---- mirror phantom ----
      if (has('mirrorPhantom')) {
        // Record player state for delayed phantom
        s.phantomInputBuffer.push({ t: now, x: p.x, vy: p.vy });
        while (s.phantomInputBuffer.length > 240) s.phantomInputBuffer.shift();
        
        // Get phantom position from 500ms ago
        let phantomX = level.width - (p.x + p.w);
        let phantomVy = 0;
        const delayTarget = now - 500;
        for (const entry of s.phantomInputBuffer) {
          if (entry.t <= delayTarget) {
            phantomX = level.width - (entry.x + p.w);
            phantomVy = entry.vy;
          } else {
            break;
          }
        }
        
        const phantom = { x: phantomX, y: p.y + (phantomVy * dt * 2), w: p.w, h: p.h };
        if (rectsOverlap(box(), phantom)) {
          die();
          return;
        }
        s.phantom = phantom;
      }

      // ---- chase wall ----
      if (has('chaseWall')) {
        s.chaseWallX += (1.1 + s.time / 22000) * dt;
        if (s.chaseWallX > p.x - 10) {
          die();
          return;
        }
      }

      // ---- coins ----
      for (const c of s.coins) {
        if (c.collected) continue;
        if (rectsOverlap(box(), { x: c.x - 14, y: c.y - 14, w: 28, h: 28 })) {
          c.collected = true;
          if (c.fake) {
            audio.fakeCoin();
            die();
            return;
          } else {
            audio.coin();
          }
        }
      }

      // ---- checkpoint troll ----
      if (level.checkpoint && has('checkpointTroll') && !s.checkpointDone) {
        if (rectsOverlap(box(), { x: level.checkpoint.x - 20, y: level.checkpoint.y - 40, w: 40, h: 60 })) {
          s.checkpointDone = true;
          s.done = true;
          audio.buzz();
          setCheckpointMsg(true);
          setTimeout(() => onCheckpointTrap(), 1900);
        }
      }

      // ---- fake popup ----
      if (has('fakePopup') && !s.popupShown && p.x > level.width * 0.35) {
        s.popupShown = true;
        setPopup({ visible: true });
        setTimeout(() => setPopup(null), 1700);
      }

      // ---- sound barrier ----
      if (has('soundBarrier') && !s.soundBarrierShown && p.x > level.width * 0.4) {
        s.soundBarrierShown = true;
        audio.buzz();
        s.shake = 18;
        setWarningFlash(true);
        setTimeout(() => setWarningFlash(false), 900);
      }

      // ---- blackout flicker ----
      if (has('blackoutFlicker')) {
        s.blackoutTimer += rawDt * 16.6667;
        if (!s.blackoutOn && s.blackoutTimer > 2000) {
          s.blackoutOn = true;
          s.blackoutTimer = 0;
        } else if (s.blackoutOn && s.blackoutTimer > 420) {
          s.blackoutOn = false;
          s.blackoutTimer = 0;
        }
      }

      // ---- flag runaway ----
      const dxFlag = p.x - s.flag.x;
      if (level.flag.runaway) {
        const dist = Math.abs(dxFlag);
        if (dist < 190) {
          const dir = dxFlag > 0 ? 1 : -1;
          s.flag.x += dir * 2.6 * dt;
          s.flag.x = Math.max(160, Math.min(level.width - 90, s.flag.x));
        }
      }

      // ---- flag catch ----
      if (rectsOverlap(box(), { x: s.flag.x - 10, y: s.flag.y - 60, w: 50, h: 90 })) {
        if (has('fakeEnding') && !s.fakeEndTricked) {
          s.done = true;
          setFakeEndOverlay(true);
        } else {
          s.done = true;
          audio.flag();
          onComplete();
        }
      }

      // ---- world bounds / death ----
      if (has('falseBoundaryDeath') && p.x < 4) {
        die();
        return;
      }
      p.x = Math.max(0, Math.min(level.width - p.w, p.x));
      if (p.y > level.height + 160 || p.y < -400) {
        die();
        return;
      }

      // ---- camera ----
      const targetCam = p.x + p.w / 2 - VIEW_W / 2;
      s.camera.x += (targetCam - s.camera.x) * Math.min(1, 0.18 * dt);
      s.camera.x = Math.max(0, Math.min(Math.max(0, level.width - VIEW_W), s.camera.x));

      if (s.shake > 0) s.shake = Math.max(0, s.shake - 0.9 * dt);

      // Air spin (rolling effect while jumping)
      if (!p.grounded) {
        p.rot = (p.rot || 0) + p.vx * 0.045 * dt;
      } else {
        p.rot = (p.rot || 0) * 0.75;
      }

      // Update particles
      for (const part of s.particles) {
        part.x += part.vx * dt;
        part.y += part.vy * dt;
        part.vy += 0.06 * dt;
        part.vx *= 0.98;
        part.life -= dt;
      }
      s.particles = s.particles.filter((part: Particle) => part.life > 0);
    };

    const handleLanding = (s: any, pl: RuntimePlatform, _now: number) => {
      if (pl.type === 'falling' && !pl.falling) {
        pl.falling = true;
        pl.fallVy = 0.5;
      }
      if (pl.type === 'quiz' && !pl.correct && !pl.falling) {
        pl.falling = true;
        pl.fallVy = 0.5;
      }
      if (pl.type === 'slope') {
        s.player.vy = -16.5;
        audio.jump();
      }
      if (pl.type === 'teleport' && !pl.quizBroken) {
        pl.quizBroken = true;
        s.player.x = level.spawn.x;
        s.player.y = level.spawn.y;
        s.player.vx = 0;
        s.player.vy = 0;
        audio.teleport();
        onDeath();
        setTimeout(() => {
          pl.quizBroken = false;
        }, 400);
      }
      if (!pl.falling && pl.type !== 'teleport') audio.land();
    };

    const drawRoundRect = (c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) => {
      c.beginPath();
      c.moveTo(x + r, y);
      c.arcTo(x + w, y, x + w, y + h, r);
      c.arcTo(x + w, y + h, x, y + h, r);
      c.arcTo(x, y + h, x, y, r);
      c.arcTo(x, y, x + w, y, r);
      c.closePath();
    };

    const render = (c: CanvasRenderingContext2D, s: any, now: number) => {
      c.save();
      c.fillStyle = '#05060a';
      c.fillRect(0, 0, VIEW_W, VIEW_H);
      if (!s) {
        c.restore();
        return;
      }

      // parallax dots
      c.save();
      c.globalAlpha = 0.35;
      c.fillStyle = level.accent || '#22d3ee';
      const parX = -(s.camera.x * 0.3) % 60;
      for (let i = -1; i < VIEW_W / 60 + 2; i++) {
        for (let j = 0; j < VIEW_H / 60 + 1; j++) {
          c.fillRect(parX + i * 60, j * 60 + 20, 2, 2);
        }
      }
      c.restore();

      const shakeX = s.shake > 0 ? (Math.random() - 0.5) * s.shake : 0;
      const shakeY = s.shake > 0 ? (Math.random() - 0.5) * s.shake : 0;

      c.save();
      c.translate(-s.camera.x + shakeX, shakeY);

      // platforms
      for (const pl of s.platforms) {
        if (pl.removed) continue;
        if (now < pl.vanishUntil) continue;
        drawPlatform(c, pl, s, now);
      }

      // checkpoint
      if (level.checkpoint) {
        const cp = level.checkpoint;
        c.strokeStyle = '#34d399';
        c.fillStyle = 'rgba(52,211,153,0.15)';
        c.lineWidth = 2;
        c.beginPath();
        c.moveTo(cp.x, cp.y);
        c.lineTo(cp.x, cp.y - 45);
        c.stroke();
        c.beginPath();
        c.moveTo(cp.x, cp.y - 45);
        c.lineTo(cp.x + 26, cp.y - 37);
        c.lineTo(cp.x, cp.y - 29);
        c.closePath();
        c.fill();
        c.stroke();
      }

      // hazards
      for (const hz of s.hazards) {
        if (hz.type === 'spike') {
          c.fillStyle = '#e2e8f0';
          c.beginPath();
          const n = Math.max(1, Math.round(hz.w / 14));
          for (let i = 0; i < n; i++) {
            const sx = hz.x + (i * hz.w) / n;
            c.moveTo(sx, hz.y + hz.h);
            c.lineTo(sx + hz.w / n / 2, hz.y);
            c.lineTo(sx + hz.w / n, hz.y + hz.h);
          }
          c.fill();
        } else if (hz.type === 'ceilingSpike' && hz.state !== 'idle') {
          c.fillStyle = '#f87171';
          c.beginPath();
          c.moveTo(hz.x, hz.curY);
          c.lineTo(hz.x + hz.w / 2, hz.curY + hz.h);
          c.lineTo(hz.x + hz.w, hz.curY);
          c.closePath();
          c.fill();
        }
      }

      // coins
      for (const co of s.coins) {
        if (co.collected) continue;
        c.beginPath();
        c.fillStyle = '#facc15';
        c.strokeStyle = '#fde68a';
        c.lineWidth = 2;
        c.arc(co.x, co.y, 12, 0, Math.PI * 2);
        c.fill();
        c.stroke();
      }

      // bullets
      c.fillStyle = '#f472b6';
      for (const b of s.bullets) {
        c.beginPath();
        c.arc(b.x, b.y, 7, 0, Math.PI * 2);
        c.fill();
      }

      // mirror phantom
      if (s.phantom) {
        c.strokeStyle = '#f43f5e';
        c.fillStyle = 'rgba(244,63,94,0.18)';
        c.lineWidth = 2;
        c.fillRect(s.phantom.x, s.phantom.y, s.phantom.w, s.phantom.h);
        c.strokeRect(s.phantom.x, s.phantom.y, s.phantom.w, s.phantom.h);
      }

      // chase wall
      if (level.mechanics.includes('chaseWall')) {
        const grad = c.createLinearGradient(s.chaseWallX - 60, 0, s.chaseWallX, 0);
        grad.addColorStop(0, 'rgba(248,113,113,0)');
        grad.addColorStop(1, 'rgba(248,113,113,0.9)');
        c.fillStyle = grad;
        c.fillRect(s.chaseWallX - 60, 0, 60, level.height);
      }

      // flag
      c.strokeStyle = level.accent || '#22d3ee';
      c.lineWidth = 3;
      c.beginPath();
      c.moveTo(s.flag.x, s.flag.y);
      c.lineTo(s.flag.x, s.flag.y - 60);
      c.stroke();
      c.fillStyle = level.accent || '#22d3ee';
      c.beginPath();
      c.moveTo(s.flag.x, s.flag.y - 60);
      c.lineTo(s.flag.x + 32, s.flag.y - 48);
      c.lineTo(s.flag.x, s.flag.y - 36);
      c.closePath();
      c.fill();

      // particles
      for (const part of s.particles) {
        const alpha = Math.max(0, part.life / 24);
        c.globalAlpha = alpha;
        c.fillStyle = part.color;
        c.fillRect(part.x, part.y, part.size, part.size);
      }
      c.globalAlpha = 1;

      // player
      const p = s.player;
      const pw = p.w * p.sizeMul;
      const ph = p.h * p.sizeMul;
      const px = p.x - (p.sizeMul - 1) * 15;
      const py = p.y - (p.sizeMul - 1) * 15;
      const rot = p.rot || 0;
      c.save();
      c.translate(px + pw / 2, py + ph / 2);
      c.rotate(rot);
      c.shadowColor = level.accent || '#22d3ee';
      c.shadowBlur = 18;
      c.fillStyle = level.accent || '#22d3ee';
      drawRoundRect(c, -pw / 2, -ph / 2, pw, ph, 6);
      c.fill();
      c.strokeStyle = '#fff';
      c.lineWidth = 1.5;
      drawRoundRect(c, -pw / 2, -ph / 2, pw, ph, 6);
      c.stroke();
      c.restore();

      c.restore();

      // blackout
      if (s.blackoutOn) {
        c.fillStyle = '#000';
        c.fillRect(0, 0, VIEW_W, VIEW_H);
      }

      // low light vignette
      c.restore();
    };

    const drawPlatform = (c: CanvasRenderingContext2D, pl: RuntimePlatform, s: any, now: number) => {
      if (pl.type === 'invisible') {
        const p = s.player;
        const dist = Math.hypot(p.x - pl.x, p.y - pl.y);
        const alpha = Math.max(0, 1 - dist / 150);
        if (alpha <= 0.02) return;
        c.globalAlpha = alpha;
        c.fillStyle = level.accent || '#22d3ee';
        c.fillRect(pl.x, pl.y, pl.w, pl.h);
        c.globalAlpha = 1;
        return;
      }
      if (pl.type === 'schrodinger') {
        const flicker = 0.35 + 0.25 * Math.sin(now / 160 + pl.x);
        c.globalAlpha = flicker;
        c.fillStyle = '#93c5fd';
        c.fillRect(pl.x, pl.y, pl.w, pl.h);
        c.globalAlpha = 1;
        return;
      }
      if (pl.type === 'bouncy') {
        c.fillStyle = '#fb7185';
        c.fillRect(pl.x, pl.y, pl.w, 10);
        c.fillStyle = '#3f0d17';
        c.fillRect(pl.x, pl.y + 10, pl.w, pl.h - 10);
        return;
      }
      if (pl.type === 'slope') {
        c.fillStyle = '#5eead4';
        c.beginPath();
        c.moveTo(pl.x, pl.y + pl.h);
        c.lineTo(pl.x + pl.w, pl.y);
        c.lineTo(pl.x + pl.w, pl.y + pl.h);
        c.closePath();
        c.fill();
        return;
      }
      if (pl.type === 'conveyor') {
        c.fillStyle = '#134e4a';
        c.fillRect(pl.x, pl.y, pl.w, pl.h);
        c.fillStyle = '#2dd4bf';
        c.fillRect(pl.x, pl.y, pl.w, 8);
        const dir = s.conveyorDir;
        c.fillStyle = '#0f766e';
        for (let i = 0; i < pl.w; i += 14) {
          c.beginPath();
          const cx = pl.x + i + (dir > 0 ? (now / 80) % 14 : -(now / 80) % 14);
          c.moveTo(cx, pl.y + 20);
          c.lineTo(cx + dir * 8, pl.y + 14);
          c.lineTo(cx, pl.y + 8);
          c.fill();
        }
        return;
      }
      if (pl.type === 'moving') {
        c.fillStyle = '#78350f';
        c.fillRect(pl.x, pl.y, pl.w, pl.h);
        c.strokeStyle = '#fb923c';
        c.lineWidth = 2;
        c.strokeRect(pl.x, pl.y, pl.w, pl.h);
        return;
      }
      if (pl.type === 'quiz') {
        c.fillStyle = '#1e293b';
        c.fillRect(pl.x, pl.y, pl.w, pl.h);
        c.strokeStyle = '#facc15';
        c.strokeRect(pl.x, pl.y, pl.w, pl.h);
        c.fillStyle = '#facc15';
        c.font = 'bold 16px monospace';
        c.textAlign = 'center';
        c.fillText(pl.label || '?', pl.x + pl.w / 2, pl.y + pl.h / 2 + 6);
        return;
      }
      // normal / falling / decorative / teleport (visually identical - hidden trolls)
      c.fillStyle = pl.falling ? '#0e7490' : '#0e2a33';
      c.fillRect(pl.x, pl.y, pl.w, pl.h);
      c.strokeStyle = level.accent || '#22d3ee';
      c.globalAlpha = 0.7;
      c.lineWidth = 2;
      c.strokeRect(pl.x + 1, pl.y + 1, pl.w - 2, Math.min(pl.h, 40));
      c.globalAlpha = 1;
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [level, buildRuntime, onComplete, onDeath, onCheckpointTrap, onControlIndicator, touchRef]);

  const insetStyle = (side: 'top' | 'bottom' | 'left' | 'right'): React.CSSProperties => {
    const base: React.CSSProperties = { position: 'absolute', background: '#000', zIndex: 20, transition: 'all 120ms linear' };
    if (side === 'top') return { ...base, top: 0, left: 0, right: 0, height: cropInset };
    if (side === 'bottom') return { ...base, bottom: 0, left: 0, right: 0, height: cropInset };
    if (side === 'left') return { ...base, top: 0, bottom: 0, left: 0, width: cropInset };
    return { ...base, top: 0, bottom: 0, right: 0, width: cropInset };
  };

  return (
    <div className="relative w-full h-full select-none" style={{ maxWidth: '100vw', maxHeight: '100vh', overflow: 'hidden' }}>
      <canvas ref={canvasRef} width={VIEW_W} height={VIEW_H} className="w-full h-full rounded-xl bg-black block" style={{ width: '100%', height: '100%' } } />
      {cropInset > 0 && (
        <>
          <div style={insetStyle('top')} />
          <div style={insetStyle('bottom')} />
          <div style={insetStyle('left')} />
          <div style={insetStyle('right')} />
        </>
      )}
      {warningFlash && (
        <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none animate-pulse">
          <span className="text-red-500 font-black text-3xl tracking-widest drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]">⚠ WARNING ⚠</span>
        </div>
      )}
      {popup && popup.visible && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/10">
          <div className="w-[80%] max-w-sm rounded-lg border-4 border-yellow-400 bg-slate-100 p-4 shadow-2xl text-slate-900 text-center animate-[bounce_1s_ease-in-out_infinite]">
            <p className="font-extrabold text-lg text-red-600">🎉 YOU HAVE WON A PRIZE! 🎉</p>
            <p className="text-sm mt-1">Claim your FREE neon square upgrade now!</p>
            <div className="mt-2 flex justify-between text-xs text-slate-500">
              <span>Skip Ad in 2...</span>
              <span className="cursor-not-allowed border px-2 rounded">Close ✕</span>
            </div>
          </div>
        </div>
      )}
      {fakeEndOverlay && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70">
          <div className="rounded-2xl border border-white/10 bg-slate-900 p-8 text-center shadow-2xl">
            <h2 className="text-2xl font-bold text-emerald-400">Level Complete!</h2>
            <p className="mt-2 text-sm text-slate-400">...or is it?</p>
            <button
              onClick={() => {
                const s = stateRef.current;
                s.fakeEndTricked = true;
                setFakeEndOverlay(false);
                s.done = false;
                s.dead = true;
                audio.death();
                onDeath();
                setTimeout(() => {
                  const fresh = buildRuntime(level);
                  fresh.fakeEndTricked = true;
                  stateRef.current = fresh;
                }, 260);
              }}
              className="mt-4 rounded-lg bg-emerald-500 px-5 py-2 font-semibold text-slate-950 hover:bg-emerald-400"
            >
              Next Level →
            </button>
          </div>
        </div>
      )}
      {checkpointMsg && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/80">
          <div className="rounded-2xl border border-emerald-400/30 bg-slate-900 p-8 text-center shadow-2xl">
            <h2 className="text-2xl font-bold text-emerald-400">Checkpoint Reached!</h2>
            <p className="mt-2 text-sm text-slate-400">...progress reset to Level 1. Sorry, not sorry.</p>
          </div>
        </div>
      )}
    </div>
  );
}
