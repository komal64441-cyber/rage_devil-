export type PlatformType =
  | 'normal'
  | 'falling'
  | 'invisible'
  | 'decorative'
  | 'ice'
  | 'bouncy'
  | 'vanishOnJump'
  | 'conveyor'
  | 'teleport'
  | 'quiz'
  | 'schrodinger'
  | 'slope'
  | 'moving';

export interface Platform {
  x: number;
  y: number;
  w: number;
  h: number;
  type: PlatformType;
  moveRange?: number;
  moveSpeed?: number;
  moveAxis?: 'x' | 'y';
  conveyorDir?: 1 | -1;
  label?: string;
  correct?: boolean;
}

export type HazardType = 'spike' | 'ceilingSpike' | 'turret';

export interface Hazard {
  x: number;
  y: number;
  w: number;
  h: number;
  type: HazardType;
  triggerRadius?: number;
}

export interface Coin {
  x: number;
  y: number;
  fake?: boolean;
}

export interface FlagDef {
  x: number;
  y: number;
  runaway?: boolean;
}

export interface GravityZone {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface WindZone {
  x: number;
  y: number;
  w: number;
  h: number;
  force: number;
}

export interface LowCeilingZone {
  x: number;
  y: number;
  w: number;
  h: number;
  maxJump: number;
}

export type Mechanic =
  | 'keyScramble'
  | 'reverseControls'
  | 'mirrorPhantom'
  | 'inputLag'
  | 'shrinkWindow'
  | 'soundBarrier'
  | 'blackoutFlicker'
  | 'ghostInputs'
  | 'chaseWall'
  | 'slowMotionOnJump'
  | 'falseBoundaryDeath'
  | 'lowCeiling'
  | 'doubleJumpDestroysFloor'
  | 'fakePopup'
  | 'sizeChangeRandom'
  | 'fakeEnding'
  | 'checkpointTroll'
  | 'pixelPerfect'
  | 'illusionMaze'
  | 'ghostFloor'
  | 'finalGauntlet';

export interface Level {
  id: number;
  world: number;
  name: string;
  subtitle: string;
  width: number;
  height: number;
  spawn: { x: number; y: number };
  platforms: Platform[];
  hazards: Hazard[];
  coins?: Coin[];
  flag: FlagDef;
  gravityZones?: GravityZone[];
  windZones?: WindZone[];
  lowCeilingZones?: LowCeilingZone[];
  checkpoint?: { x: number; y: number };
  mechanics: Mechanic[];
  friction?: number;
  accent?: string;
}
