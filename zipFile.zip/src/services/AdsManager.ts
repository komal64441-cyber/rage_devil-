import { AdMob, BannerAdPosition, BannerAdSize } from '@capacitor-community/admob';
import { Capacitor } from '@capacitor/core';

// AdMob IDs
const APP_ID = 'ca-app-pub-4680298321698683~9266585690';
const BANNER_AD_UNIT_ID = 'ca-app-pub-4680298321698683/2074082268';
const INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-4680298321698683/2074082268';

export class AdsManager {
  private static instance: AdsManager | null = null;
  private initialized = false;
  private bannerVisible = false;
  private interstitialReady = false;
  private isNative = false;

  static getInstance(): AdsManager {
    if (!AdsManager.instance) {
      AdsManager.instance = new AdsManager();
    }
    return AdsManager.instance;
  }

  private constructor() {
    this.isNative = Capacitor.isNativePlatform();
  }

  async initialize(): Promise<void> {
    if (!this.isNative) {
      console.log('[Ads] Web platform - ads disabled');
      return;
    }

    if (this.initialized) {
      console.log('[Ads] Already initialized');
      return;
    }

    try {
      console.log('[Ads] Initializing AdMob with app ID:', APP_ID);
      await AdMob.initialize({
        testingDevices: [],
      });

      this.initialized = true;
      console.log('[Ads] AdMob initialized successfully');
    } catch (error) {
      console.error('[Ads] Initialization failed:', error);
    }
  }

  async showBanner(): Promise<void> {
    if (!this.isNative || !this.initialized || this.bannerVisible) {
      return;
    }

    try {
      console.log('[Ads] Showing banner ad');
      await AdMob.showBanner({
        adId: BANNER_AD_UNIT_ID,
        adSize: BannerAdSize.ADAPTIVE_BANNER,
        position: BannerAdPosition.BOTTOM_CENTER,
        margin: 0,
      });
      this.bannerVisible = true;
      console.log('[Ads] Banner shown');
    } catch (error) {
      console.error('[Ads] Banner show failed:', error);
    }
  }

  async hideBanner(): Promise<void> {
    if (!this.isNative || !this.initialized || !this.bannerVisible) {
      return;
    }

    try {
      console.log('[Ads] Hiding banner ad');
      await AdMob.hideBanner();
      this.bannerVisible = false;
      console.log('[Ads] Banner hidden');
    } catch (error) {
      console.error('[Ads] Banner hide failed:', error);
    }
  }

  async prepareInterstitial(): Promise<void> {
    if (!this.isNative || !this.initialized) {
      return;
    }

    try {
      console.log('[Ads] Preparing interstitial ad');
      await AdMob.prepareInterstitial({
        adId: INTERSTITIAL_AD_UNIT_ID,
      });
      this.interstitialReady = true;
      console.log('[Ads] Interstitial ready');
    } catch (error) {
      console.error('[Ads] Interstitial preparation failed:', error);
    }
  }

  async showInterstitial(): Promise<boolean> {
    if (!this.isNative || !this.initialized || !this.interstitialReady) {
      console.log('[Ads] Interstitial not ready, skipping');
      return false;
    }

    try {
      console.log('[Ads] Showing interstitial ad');
      await AdMob.showInterstitial();
      this.interstitialReady = false;
      console.log('[Ads] Interstitial shown');
      // Pre-load next interstitial
      this.prepareInterstitial().catch(() => {});
      return true;
    } catch (error) {
      console.error('[Ads] Interstitial show failed:', error);
      return false;
    }
  }

  isInitialized(): boolean {
    return this.initialized;
  }

  isNativePlatform(): boolean {
    return this.isNative;
  }
}

// Export singleton instance for convenience
export const ads = AdsManager.getInstance();
